#pragma once
class test
{
};

